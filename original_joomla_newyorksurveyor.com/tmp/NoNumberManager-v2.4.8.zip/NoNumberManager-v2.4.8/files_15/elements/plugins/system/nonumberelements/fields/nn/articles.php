<?php
// No direct access
defined( '_JEXEC' ) or die();

// Load common functions
require_once str_replace( DS.'nn'.DS, DS, __FILE__ );