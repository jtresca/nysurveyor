/**
 * JavaScript file for Element: Toggler (MooTools 1.2 compatible)
 * Adds slide in and out functionality to elements based on an elements value
 *
 * @package     NoNumber! Elements
 * @version     2.5.0
 *
 * @author      Peter van Westen <peter@nonumber.nl>
 * @link        http://www.nonumber.nl
 * @copyright   Copyright © 2011 NoNumber! All Rights Reserved
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

/* File moved... this is for backward compatibility */
var all_scripts = document.getElementsByTagName("script");
var nn_script_root = all_scripts[all_scripts.length-1].src.replace( /[^\/]*\.js$/, '' );
document.write('<script src="'+nn_script_root+'toggler.js" type="text/JavaScript"><\/script>');